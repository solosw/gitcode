# yysScript 阴阳师护肝脚本
 阴阳师脚本 支持御魂副本多开 觉得好用的话请点个star吧~

## 注意事项

1、支持任意安卓模拟器和官方PC端，任意分辨率（不要过小即可），在运行过程中不能遮挡游戏界面。

2、如果鼠标无法移动或者点击，要用右键点击，使用管理员身份运行Windows.exe程序。

3、如果游戏更新后修改了一些图片，可以手动截图替换掉img路径下的图片。

4、只需要软件不需要源码研究的可以在[点击此处打开下载页面](https://github.com/li-zheng-hao/yysScript/releases)中下载压缩包解压即可用。

## v2.0版本更新

1、大幅优化准确率和速度，目前测试双开无问题，理论上支持任意多个程序同时跑（一般不超过4个比较好）。

2、F4快捷键停止脚本（缺点就是焦点要在脚本程序上，否则无效）。

3、将一些bug修复，修改脚本UI。

4、增加日志功能，查看当前运行状态。

## 软件截图

![image](https://github.com/li-zheng-hao/yysscript/raw/master/Doc/screenshot.jpg)

![image](https://github.com/li-zheng-hao/yysscript/raw/master/Doc/screenshot2.png)</br>
